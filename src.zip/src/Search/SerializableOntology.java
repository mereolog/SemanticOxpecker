/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Search;

import java.io.*;
import java.util.HashMap;

/**
 *
 * @author PG
 */
public class SerializableOntology implements Serializable {
    
    public HashMap<Integer, Prepare.Paper> paperMap;
}
